


int bitAnd(int, int);
int test_bitAnd(int, int);
int bitNor(int, int);
int test_bitNor(int, int);
int copyLSB(int);
int test_copyLSB(int);
int evenBits();
int test_evenBits();
int logicalShift(int, int);
int test_logicalShift(int, int);
int bang(int);
int test_bang(int);
int leastBitPos(int);
int test_leastBitPos(int);
int isNotEqual(int, int);
int test_isNotEqual(int, int);
int negate(int);
int test_negate(int);
int isPositive(int);
int test_isPositive(int);
int isNonNegative(int);
int test_isNonNegative(int);
int sum3(int, int, int);
int test_sum3(int, int, int);
int addOK(int, int);
int test_addOK(int, int);
int abs(int);
int test_abs(int);
int isNonZero(int);
int test_isNonZero(int);
